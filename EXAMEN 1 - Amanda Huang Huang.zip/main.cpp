#include <iostream>
#include <string>
#include "Producto.h"

using namespace std;


int main() {
const int FILAS = 3;
const int COLuMNAS = 3;

    int matriz[FILAS][COLuMNAS]={0};
}
