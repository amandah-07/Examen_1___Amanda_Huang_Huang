#include <iostream>
#include <string>
using namespace std;

class Producto {
private:
    string nombre;
    int precio;
    int cantidadDisponible;

public:
    Producto() {};
    Producto(string nombre, int precio, int cantidadDisponible) {};
    string getNombre(){return nombre;};
    int getPrecio(){return precio;};
    int getcantidadDisponible(){return cantidadDisponible;};
    Producto consultar(string nombre, int precio, int cantidadDisponible){};
    Producto registrar(string nombre, int cantidadDisponible){};
    Producto calcular(string nombre,int precio){}

};