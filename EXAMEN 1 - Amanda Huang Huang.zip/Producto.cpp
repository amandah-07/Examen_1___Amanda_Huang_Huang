#include <iostream>
#include <string>
#include "Producto.h"
using namespace std;

Producto::Producto(){
    {
        nombre = "";
        precio = 0;
        cantidadDisponible = 0;
    }

Producto::Producto(string,int, int){
        this->nombre = nombre;
        this->precio = precio;
        this->cantidadDisponible = cantidadDisponible;
    }

    string Producto::getNombre(){
        return nombre;
    }

    int Producto::getPrecio(){
        return precio;
    }

    int Producto::getcantidadDisponible(){
        return cantidadDisponible;
    }

Producto::consultar(nombre, precio, cantidadDisponible){

    }


//Parte C
    Producto menu(nombre, precio, cantidadDisponible){
        int opcion;
        cout << " --------------Menu principal----------- " << endl;
        cout << "Digite 0 si quiere salir" << endl;
        cout << "Digite 1 si quiere que le muestra productos" << endl;
        cout << "Digite 2 si quiere que le registra venta" << endl;
        cout << "Digite un numero correspondiente con respecto a su necesidad" << endl;
        cin >> opcion;

        if(opcion == 0) {
            return -1;
        }
        if(opcion == 1) {

        }
    }


};

